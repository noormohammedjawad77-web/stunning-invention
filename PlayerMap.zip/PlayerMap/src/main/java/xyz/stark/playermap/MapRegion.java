package xyz.stark.playermap;

public record MapRegion(String name, String world,
                        int minX, int minY, int minZ,
                        int maxX, int maxY, int maxZ) {

    public boolean contains(String worldName, int x, int y, int z) {
        return x >= minX && x <= maxX
                && y >= minY && y <= maxY
                && z >= minZ && z <= maxZ
                && world.equals(worldName);
    }
}
