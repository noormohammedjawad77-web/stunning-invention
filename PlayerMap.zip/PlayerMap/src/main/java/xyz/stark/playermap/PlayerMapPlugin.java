package xyz.stark.playermap;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.GameMode;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class PlayerMapPlugin extends JavaPlugin implements Listener, TabExecutor {

    private static final String PERM = "playermap.admin";
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private final Map<String, MapRegion> regionMap = new LinkedHashMap<>();
    private final Map<UUID, Location> pos1 = new HashMap<>();
    private final Map<UUID, Location> pos2 = new HashMap<>();

    private volatile MapRegion[] regions = new MapRegion[0];
    private volatile Map<String, Integer> counts = Map.of();
    private volatile int total = 0;
    private boolean ignoreSpectators = true;
    private BukkitTask task;

    private NamespacedKey wandKey;
    private File dataFile;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        wandKey = new NamespacedKey(this, "wand");
        dataFile = new File(getDataFolder(), "regions.yml");
        loadAll();

        getServer().getPluginManager().registerEvents(this, this);
        var cmd = getCommand("playermap");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }

        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new PlayerMapExpansion(this).register();
            getLogger().info("PlaceholderAPI hooked: %playermap_count%");
        } else {
            getLogger().warning("PlaceholderAPI not found, the %playermap_count% variable is disabled.");
        }
    }

    public int getCount(String key) {
        if (key.equalsIgnoreCase("count")) {
            return total;
        }
        return counts.getOrDefault(key.toLowerCase(Locale.ROOT), 0);
    }

    private void updateCounts() {
        MapRegion[] snapshot = regions;
        if (snapshot.length == 0) {
            counts = Map.of();
            total = 0;
            return;
        }
        Map<String, Integer> result = new HashMap<>();
        for (MapRegion r : snapshot) {
            result.put(r.name().toLowerCase(Locale.ROOT), 0);
        }
        int all = 0;
        for (Player p : getServer().getOnlinePlayers()) {
            if (ignoreSpectators && p.getGameMode() == GameMode.SPECTATOR) {
                continue;
            }
            Location loc = p.getLocation();
            World world = loc.getWorld();
            if (world == null) {
                continue;
            }
            String worldName = world.getName();
            int x = loc.getBlockX();
            int y = loc.getBlockY();
            int z = loc.getBlockZ();
            boolean counted = false;
            for (MapRegion r : snapshot) {
                if (r.contains(worldName, x, y, z)) {
                    result.merge(r.name().toLowerCase(Locale.ROOT), 1, Integer::sum);
                    counted = true;
                }
            }
            if (counted) {
                all++;
            }
        }
        counts = result;
        total = all;
    }

    private void loadAll() {
        reloadConfig();
        ignoreSpectators = getConfig().getBoolean("ignore-spectators", true);
        long interval = Math.max(5L, getConfig().getLong("update-interval-ticks", 20L));

        regionMap.clear();
        if (dataFile.exists()) {
            YamlConfiguration cfg = YamlConfiguration.loadConfiguration(dataFile);
            ConfigurationSection section = cfg.getConfigurationSection("regions");
            if (section != null) {
                for (String key : section.getKeys(false)) {
                    ConfigurationSection s = section.getConfigurationSection(key);
                    if (s == null) {
                        continue;
                    }
                    String world = s.getString("world");
                    if (world == null) {
                        continue;
                    }
                    regionMap.put(key.toLowerCase(Locale.ROOT), new MapRegion(key, world,
                            s.getInt("min-x"), s.getInt("min-y"), s.getInt("min-z"),
                            s.getInt("max-x"), s.getInt("max-y"), s.getInt("max-z")));
                }
            }
        }
        rebuild();

        if (task != null) {
            task.cancel();
        }
        task = getServer().getScheduler().runTaskTimer(this, this::updateCounts, 20L, interval);
    }

    private void rebuild() {
        regions = regionMap.values().toArray(new MapRegion[0]);
    }

    private void saveRegions() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (MapRegion r : regionMap.values()) {
            String base = "regions." + r.name() + ".";
            cfg.set(base + "world", r.world());
            cfg.set(base + "min-x", r.minX());
            cfg.set(base + "min-y", r.minY());
            cfg.set(base + "min-z", r.minZ());
            cfg.set(base + "max-x", r.maxX());
            cfg.set(base + "max-y", r.maxY());
            cfg.set(base + "max-z", r.maxZ());
        }
        try {
            cfg.save(dataFile);
        } catch (IOException e) {
            getLogger().severe("Could not save regions.yml: " + e.getMessage());
        }
    }

    private void msg(CommandSender to, String text) {
        to.sendMessage(LEGACY.deserialize("&6[PlayerMap] &f" + text));
    }

    private ItemStack createWand() {
        ItemStack item = new ItemStack(Material.BLAZE_ROD);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(LEGACY.deserialize("&6PlayerMap Wand"));
        meta.lore(List.of(
                LEGACY.deserialize("&7Left click: position 1"),
                LEGACY.deserialize("&7Right click: position 2")));
        meta.getPersistentDataContainer().set(wandKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    private boolean isWand(ItemStack item) {
        if (item == null || item.getType() != Material.BLAZE_ROD || !item.hasItemMeta()) {
            return false;
        }
        return item.getItemMeta().getPersistentDataContainer().has(wandKey, PersistentDataType.BYTE);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Action action = event.getAction();
        if (action != Action.LEFT_CLICK_BLOCK && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        if (!isWand(event.getItem())) {
            return;
        }
        Player player = event.getPlayer();
        if (!player.hasPermission(PERM)) {
            return;
        }
        Block block = event.getClickedBlock();
        if (block == null) {
            return;
        }
        event.setCancelled(true);

        Location loc = block.getLocation();
        String text = loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ();
        if (action == Action.LEFT_CLICK_BLOCK) {
            pos1.put(player.getUniqueId(), loc);
            msg(player, "Position 1 set: &e" + text);
        } else {
            pos2.put(player.getUniqueId(), loc);
            msg(player, "Position 2 set: &e" + text);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        pos1.remove(event.getPlayer().getUniqueId());
        pos2.remove(event.getPlayer().getUniqueId());
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission(PERM)) {
            msg(sender, "&cYou don't have permission.");
            return true;
        }
        if (args.length == 0) {
            msg(sender, "&e/playermap wand &7- get the selection wand");
            msg(sender, "&e/playermap create <name> <extraHeight> &7- create a map from your selection");
            msg(sender, "&e/playermap delete <name>");
            msg(sender, "&e/playermap list");
            msg(sender, "&e/playermap reload");
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "wand" -> {
                if (!(sender instanceof Player player)) {
                    msg(sender, "&cPlayers only.");
                    return true;
                }
                player.getInventory().addItem(createWand());
                msg(player, "You received the wand.");
            }
            case "create" -> {
                if (!(sender instanceof Player player)) {
                    msg(sender, "&cPlayers only.");
                    return true;
                }
                create(player, args);
            }
            case "delete" -> {
                if (args.length < 2) {
                    msg(sender, "&cUsage: /playermap delete <name>");
                    return true;
                }
                MapRegion removed = regionMap.remove(args[1].toLowerCase(Locale.ROOT));
                if (removed == null) {
                    msg(sender, "&cMap not found.");
                    return true;
                }
                rebuild();
                saveRegions();
                msg(sender, "Deleted map &e" + removed.name() + "&f.");
            }
            case "list" -> {
                if (regionMap.isEmpty()) {
                    msg(sender, "No maps created yet.");
                    return true;
                }
                for (MapRegion r : regionMap.values()) {
                    msg(sender, "&e" + r.name() + " &7(" + r.world() + ") "
                            + r.minX() + "," + r.minY() + "," + r.minZ() + " -> "
                            + r.maxX() + "," + r.maxY() + "," + r.maxZ());
                }
            }
            case "reload" -> {
                loadAll();
                msg(sender, "Reloaded.");
            }
            default -> msg(sender, "&cUnknown subcommand.");
        }
        return true;
    }

    private void create(Player player, String[] args) {
        if (args.length < 3) {
            msg(player, "&cUsage: /playermap create <name> <extraHeight>");
            return;
        }
        String name = args[1];
        if (!name.matches("[A-Za-z0-9_-]{1,32}")) {
            msg(player, "&cName can only contain letters, numbers, _ and - (max 32).");
            return;
        }
        if (regionMap.containsKey(name.toLowerCase(Locale.ROOT))) {
            msg(player, "&cA map with that name already exists. Delete it first.");
            return;
        }
        int extra;
        try {
            extra = Integer.parseInt(args[2]);
        } catch (NumberFormatException e) {
            msg(player, "&cExtra height must be a number.");
            return;
        }
        if (extra < 0 || extra > 1000) {
            msg(player, "&cExtra height must be between 0 and 1000.");
            return;
        }

        Location a = pos1.get(player.getUniqueId());
        Location b = pos2.get(player.getUniqueId());
        if (a == null || b == null) {
            msg(player, "&cSelect both positions with the wand first.");
            return;
        }
        World world = a.getWorld();
        if (world == null || b.getWorld() == null || !world.equals(b.getWorld())) {
            msg(player, "&cBoth positions must be in the same world.");
            return;
        }

        int minX = Math.min(a.getBlockX(), b.getBlockX());
        int maxX = Math.max(a.getBlockX(), b.getBlockX());
        int minZ = Math.min(a.getBlockZ(), b.getBlockZ());
        int maxZ = Math.max(a.getBlockZ(), b.getBlockZ());
        int minY = Math.min(a.getBlockY(), b.getBlockY());
        int maxY = Math.max(a.getBlockY(), b.getBlockY()) + extra;
        maxY = Math.min(maxY, world.getMaxHeight() - 1);

        MapRegion region = new MapRegion(name, world.getName(), minX, minY, minZ, maxX, maxY, maxZ);
        regionMap.put(name.toLowerCase(Locale.ROOT), region);
        rebuild();
        saveRegions();
        msg(player, "Created map &e" + name + "&f, height &e" + minY + " &f-> &e" + maxY + " &f(+" + extra + ").");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (!sender.hasPermission(PERM)) {
            return out;
        }
        if (args.length == 1) {
            for (String s : List.of("wand", "create", "delete", "list", "reload")) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) {
                    out.add(s);
                }
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("delete")) {
            for (MapRegion r : regionMap.values()) {
                if (r.name().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) {
                    out.add(r.name());
                }
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("create")) {
            out.add("20");
        }
        return out;
    }
}
