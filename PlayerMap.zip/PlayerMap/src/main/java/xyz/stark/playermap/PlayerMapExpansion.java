package xyz.stark.playermap;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

public final class PlayerMapExpansion extends PlaceholderExpansion {

    private final PlayerMapPlugin plugin;

    public PlayerMapExpansion(PlayerMapPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "playermap";
    }

    @Override
    public @NotNull String getAuthor() {
        return "STARK NETWORK";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getPluginMeta().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer offline, @NotNull String params) {
        return String.valueOf(plugin.getCount(params));
    }
}
